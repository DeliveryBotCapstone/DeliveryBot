package com.google.sample.cloudvision;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class checking_photo extends AppCompatActivity {
    private static final String TAG = checking_photo.class.getSimpleName();
    public static String real_address;
    private EditText editNumber;
    private TextView description;
    public ArrayList<UserData> userList;
    private ImageView imageView;
    private String mJsonString;
    Button sendButton;

    protected void onCreate(Bundle savedInstanceStare){
        super.onCreate(savedInstanceStare);
        setContentView(R.layout.check_picture);
        imageView = findViewById(R.id.show_picture);
        editNumber = findViewById(R.id.editNum);
        userList = new ArrayList<UserData>();
        sendButton = (Button) findViewById(R.id.sendbutton);

        //DB 데이터 가져오기
        checking_photo.GetData task = new checking_photo.GetData();
        task.execute("http://13.209.74.128/getjson.php", "");

        UserData u1 = new UserData();
        u1.setName("박종건");
        u1.setNumber("01071672699");
        u1.setAddress("A1406");

        UserData u2 = new UserData();
        u2.setName("홍길동");
        u2.setNumber("010-1111-1111");
        u2.setAddress("A1404");

        userList.add(u1);
        userList.add(u2);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mMainImage.setImageBitmap(null);
//                editNumber.setVisibility(View.GONE);
//                sendButton.setVisibility(View.GONE);
//                description.setText("전송 요청을 보냈습니다.");

                real_address = editNumber.getText().toString();

                String name = "";
                String phoneNum = "";
                for(int i = 0; i < userList.size(); i++) {
                    if(userList.get(i).getAddress().equals(real_address)) {
                        name = userList.get(i).getName();
                        phoneNum = userList.get(i).getNumber();
                    }
                }

                Toast.makeText(getApplicationContext(), "배송 시작", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), MyService.class);
                intent.putExtra("address", real_address);
                intent.putExtra("name", name);
                intent.putExtra("number", phoneNum);
                startService(intent);
            }
        });

    }
    private class GetData extends AsyncTask<String, Void, String>{

        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(checking_photo.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "response - " + result);

            if (result == null){
                description.setText(errorString);
            }
            else {
                int start = result.indexOf("{");
                result = result.substring(start);
                mJsonString = result;
                showResult();
            }
        }


        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = "country=" + params[1];


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }

    private void showResult(){

        String TAG_JSON="webnautes";
        String TAG_NUMBER = "number";
        String TAG_ADDRESS = "address";
        String TAG_NAME = "name";


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String number = item.getString(TAG_NUMBER);
                String address = item.getString(TAG_ADDRESS);
                String name = item.getString(TAG_NAME);

                UserData userData = new UserData();

                userData.setNumber(number);
                userData.setAddress(address);
                userData.setName(name);

                userList.add(userData);
            }
        } catch (JSONException e) {
            Log.d(TAG, "showResult : ", e);
        }

    }


    private static class LableDetectionTask extends AsyncTask<Object, Void, String> {
        private final WeakReference<MainActivity> mActivityWeakReference;
        private Vision.Images.Annotate mRequest;

        LableDetectionTask(MainActivity activity, Vision.Images.Annotate annotate) {
            mActivityWeakReference = new WeakReference<>(activity);
            mRequest = annotate;
        }

        @Override
        protected String doInBackground(Object... params) {
            try {
                Log.d(TAG, "created Cloud Vision request object, sending request");
                BatchAnnotateImagesResponse response = mRequest.execute();
                return convertResponseToString(response);

            } catch (GoogleJsonResponseException e) {
                Log.d(TAG, "failed to make API request because " + e.getContent());
            } catch (IOException e) {
                Log.d(TAG, "failed to make API request because of other IOException " +
                        e.getMessage());
            }
            return "Cloud Vision API request failed. Check logs for details.";
        }

        protected void onPostExecute(String result) {
            MainActivity activity = mActivityWeakReference.get();
            if (activity != null && !activity.isFinishing()) {

                int start = result.indexOf("공학관");
                int end = result.indexOf("호");

//                while (start > end) {
//                    int num = result.substring(end + 1).indexOf("호");
//                    end += num + 1;
//                }

//                real_address = result.substring((start + 4), end);
                if (result.charAt(start + 4) == 'A') {
                    real_address = result.substring((start + 4), (start + 9));
                }
                else {
                    real_address = result.substring((start + 4), (start + 8));
                }

                Button sendButton = activity.findViewById(R.id.sendButton);
                EditText editNumber = activity.findViewById(R.id.editNumber);
                TextView description = activity.findViewById(R.id.description);
                sendButton.setVisibility(View.VISIBLE);
                editNumber.setVisibility(View.VISIBLE);
                description.setText("아래 호수가 맞지 않다면 수정하세요.");
                editNumber.setText(real_address);
            }
        }
        private static String convertResponseToString(BatchAnnotateImagesResponse response) {
            StringBuilder message = new StringBuilder("I found these things:\n\n");

            List<EntityAnnotation> labels = response.getResponses().get(0).getTextAnnotations();
            if (labels != null) {
                message.append(labels.get(0).getDescription());
                //for (EntityAnnotation label : labels) {
                //message.append(String.format(Locale.US, "%.3f: %s", label.getScore(), label.getDescription()));
                //message.append("\n");
                //}
            } else {
                message.append("nothing");
            }

            return message.toString();
        }
    }
}


