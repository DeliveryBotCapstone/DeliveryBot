package com.google.sample.cloudvision;

public class UserData {
    private String name; // 이름
    private String number; // 전화번호
    private String address; // 호수

    public String getName() {
        return name;
    }
    public String getNumber() {
        return number;
    }
    public String getAddress() {
        return address;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setNumber(String number) {
        this.number = number;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}
